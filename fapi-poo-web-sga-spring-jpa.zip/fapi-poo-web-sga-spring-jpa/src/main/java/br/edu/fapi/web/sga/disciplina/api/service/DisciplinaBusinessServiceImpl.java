
package br.edu.fapi.web.sga.disciplina.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import br.edu.fapi.web.sga.api.aluno.repository.model.DisciplinaDTO;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaRequest;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaResponse;
import br.edu.fapi.web.sga.disciplina.api.repository.DisciplinaDao;

public class DisciplinaBusinessServiceImpl implements DisciplinaBussinesService {

	@Autowired
	private DisciplinaDao disciplinaDao;

	@Override
	public DisciplinaResponse cadastrarDisciplina(DisciplinaRequest disciplina) {

		DisciplinaDTO disciplinaDTO = DisciplinaDTO.builder().nome(disciplina.getNome())
				.cargaHoraria(disciplina.getCargaHoraria()).descricao(disciplina.getDescricao()).build();
		disciplinaDao.save(disciplinaDTO);
		if (disciplinaDTO.getId() != null) {
			return DisciplinaResponse.builder().Id(disciplinaDTO.getId()).build();
		} else {
			return null;
		}
	}

	@Override
	public DisciplinaResponse DeletarDisciplina(int Id) {
		disciplinaDao.deleteById(Id);
		return null;
	}

	@Override
	public List<DisciplinaDTO> ListarDisciplina() {
		
		return (List<DisciplinaDTO>) disciplinaDao.findAll();
	}

	@Override
	public DisciplinaResponse UpdateDisciplina() {
		// TODO Auto-generated method stub
		return null;
	}
}
