package br.edu.fapi.web.sga.api.aluno.repository.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity(name = "professor")
public class ProfessorDTO {
	
	@Id
	@SequenceGenerator(name = "professor_id_generator", sequenceName = "professor_id_sequence", schema = "fapi_sga_jpa", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "professor_id_generator")
	private Integer id;
	
	@Column(name = "nome")
	private String nome;
	
	@Column(name = "especialidade")
	private String especialidade;
	
	
	

}
