package br.edu.fapi.web.sga.turma.api.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.edu.fapi.web.sga.api.aluno.repository.model.TurmaDTO;

@Repository
public interface TurmaDao extends CrudRepository<TurmaDTO, Integer> {

}
