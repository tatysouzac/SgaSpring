package br.edu.quentefrio.apirest.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Error {

	private String codigoErro;
	private String descricaoErro;
	private String detalheErro;
	
}
