package br.edu.fapi.web.sga.turma.api.model;

public class TurmaRest {

}
