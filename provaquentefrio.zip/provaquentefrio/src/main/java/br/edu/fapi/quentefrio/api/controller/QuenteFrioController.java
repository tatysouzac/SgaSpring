package br.edu.fapi.quentefrio.api.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.quentefrio.api.model.QuenteFrioError;
import br.edu.fapi.quentefrio.api.model.QuenteFrioRequest;
import br.edu.fapi.quentefrio.api.model.QuenteFrioResponse;
import br.edu.fapi.quentefrio.api.model.TempCidadeResponse;
import br.edu.fapi.quentefrio.api.model.QuenteFrioRest;
import br.edu.fapi.quentefrio.api.model.Error;
import br.edu.fapi.quentefrio.api.service.QuenteFrioService;

@RestController
public class QuenteFrioController {

	@Autowired
	private QuenteFrioService quenteFrioService;

	@PostMapping(value = "/quentefrio/cadastro")
	@ResponseBody
	public ResponseEntity<QuenteFrioRest> registrarTemperatura(@RequestBody QuenteFrioRequest temp) {
		QuenteFrioResponse qfResponse = quenteFrioService.cadastrarTemperatura(temp);
		if (qfResponse != null) {
			return ResponseEntity.ok().body(qfResponse);
		} else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("1000").descricaoErro("Erro de cadastrado.").detalheErro(
							"Falha durante cadastro da temperatura, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}

	@PutMapping(value = "/quentefrio/atualizar")
	@ResponseBody
	public ResponseEntity<Object> atualizarTemp(@RequestBody QuenteFrioRequest temp) {
		QuenteFrioResponse qfResponse = quenteFrioService.CorrigirDados(temp);
		if (qfResponse != null) {
			return ResponseEntity.ok().body(qfResponse);
		} else {

			QuenteFrioError quenteFrioError = QuenteFrioError.builder().error(Error.builder().codigoErro("1001")
					.descricaoErro("Erro em Atualizar Temperatura.")
					.detalheErro(
							"Falha durante atualização da temperatura, favor entrar em contato com a equipe de suporte.")
					.build()).build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}

	@GetMapping(value = "/quentefrio/tempcidade/{codigo_cidade}")
	@ResponseBody
	public ResponseEntity<Object> listarTempCidade(@PathParam("codigo_cidade") String codigo_cidade) {
		List<TempCidadeResponse> tempCidadeResponse = quenteFrioService.ListarTemperaturas(codigo_cidade);

		if (tempCidadeResponse != null) {
			return ResponseEntity.ok().body(tempCidadeResponse);
		} else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("1002").descricaoErro("Erro em Listar Temperatura.").detalheErro(
							"Falha durante lisatgem de temperaturas, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}

	@GetMapping(value = "/quentefrio/tempestado/{codigo_estado}")
	@ResponseBody
	public ResponseEntity<Object> listarTempEstado(@PathParam("codigo_estado") String codigo_estado) {
		List<TempCidadeResponse> tempCidadeResponse = quenteFrioService.ListarTemperaturasEstado(codigo_estado);

		if (tempCidadeResponse != null) {
			return ResponseEntity.ok().body(tempCidadeResponse);
		} else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("1002").descricaoErro("Erro em Listar Temperatura.").detalheErro(
							"Falha durante lisatgem de temperaturas, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}

}
