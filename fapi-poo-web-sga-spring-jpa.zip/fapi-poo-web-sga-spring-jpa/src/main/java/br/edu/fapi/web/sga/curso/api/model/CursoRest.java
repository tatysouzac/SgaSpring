package br.edu.fapi.web.sga.curso.api.model;

public class CursoRest {

}
