package br.edu.fapi.web.sga.professor.api.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.web.sga.api.aluno.repository.model.ProfessorDTO;
import br.edu.fapi.web.sga.professor.api.model.ProfessorRequest;
import br.edu.fapi.web.sga.professor.api.model.ProfessorResponse;
import br.edu.fapi.web.sga.professor.api.model.ProfessorRest;
import br.edu.fapi.web.sga.professor.api.service.ProfessorBusinessService;

@RestController
public class ProfessorController {

	@Autowired
	private ProfessorBusinessService professorBusinessService;

	@PostMapping(value = "/sga/professores")
	@ResponseBody
	public ResponseEntity<ProfessorRest> cadastrarProfessor(@RequestBody ProfessorRequest professor) {
		ProfessorResponse professorResponse = professorBusinessService.cadastrarProfessor(professor);
		if (professorResponse != null) {
			return ResponseEntity.ok().body(professorResponse);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	@GetMapping(value = "/sga/professores")
	@ResponseBody
	public ResponseEntity<List<ProfessorDTO>> listarProfessores() {
		List<ProfessorDTO> professorDTO = professorBusinessService.ListarProfessores();
		if (professorDTO != null) {
			return ResponseEntity.ok().body(professorDTO);
		} else {
			return null;
		}

	}

	@PutMapping(value = "/sga/professores")
	@ResponseBody
	public ResponseEntity<ProfessorRest> atualizarProfessor(@RequestBody ProfessorRest professor) {
		return null;
	}

	@DeleteMapping(value = "/sga/professores/{id-professor}")
	@ResponseBody
	public ResponseEntity<ProfessorRest> excluirProfessor(@PathParam("id-professor") int idProfessor) {
		ProfessorResponse professorResponse = professorBusinessService.DeletarProfessor(idProfessor);
		if (professorResponse != null) {
			ResponseEntity.ok().body(professorResponse);
		}
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);

	}
}
