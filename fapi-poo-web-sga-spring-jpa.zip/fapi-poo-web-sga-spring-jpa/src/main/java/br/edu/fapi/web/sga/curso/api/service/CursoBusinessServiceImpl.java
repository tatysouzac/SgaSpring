package br.edu.fapi.web.sga.curso.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.fapi.web.sga.api.aluno.repository.model.CursoDTO;
import br.edu.fapi.web.sga.curso.api.model.CursoRequest;
import br.edu.fapi.web.sga.curso.api.model.CursoResponse;
import br.edu.fapi.web.sga.curso.api.repository.CursoDao;

@Service
public class CursoBusinessServiceImpl implements CursoBusinessService {

	@Autowired
	private CursoDao cursoDao;

	@Override
	public CursoResponse cadastrarCurso(CursoRequest curso) {
		CursoDTO cursoDTO = CursoDTO.builder().nome(curso.getNome()).numPeriodos(curso.getNumPeriodos()).build();
		cursoDao.save(cursoDTO);
		if (cursoDTO.getId() != null) {
			return CursoResponse.builder().Id(cursoDTO.getId()).build();
		} else {
			return null;
		}
	}

	@Override
	public CursoResponse UpdateCurso(CursoRequest curso) {
		Optional<CursoDTO> cursoBase = cursoDao.findById(curso.getId());
		if (cursoBase.isPresent()) {
			cursoBase.get().setNome(curso.getNome());
			cursoBase.get().setNumPeriodos(curso.getNumPeriodos());
			cursoDao.save(cursoBase.get());
			return CursoResponse.builder().build();
		} else {
			return null;
		}
	}

	@Override
	public CursoResponse DeletarCurso(int Id) {
		cursoDao.deleteById(Id);
		return CursoResponse.builder().build();
	}

	@Override
	public List<CursoResponse> ListarCurso() {

		List<CursoDTO> cursoListTemp = (List<CursoDTO>) cursoDao.findAll();
		List<CursoResponse> cursoResponseList = new ArrayList<CursoResponse>();
		for (CursoDTO curso : cursoListTemp) {
			cursoResponseList.add(CursoResponse.builder().Id(curso.getId()).build());
		}
		return cursoResponseList;
	}

}
