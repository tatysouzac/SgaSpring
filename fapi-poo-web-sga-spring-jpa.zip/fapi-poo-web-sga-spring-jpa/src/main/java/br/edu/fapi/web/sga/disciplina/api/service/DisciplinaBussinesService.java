package br.edu.fapi.web.sga.disciplina.api.service;

import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaRequest;

import java.util.List;

import br.edu.fapi.web.sga.api.aluno.repository.model.DisciplinaDTO;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaResponse;

public interface DisciplinaBussinesService {

		DisciplinaResponse cadastrarDisciplina(DisciplinaRequest disciplina); 

	
		DisciplinaResponse DeletarDisciplina(int Id);
		
		List<DisciplinaDTO> ListarDisciplina();
		
		DisciplinaResponse UpdateDisciplina();
}
