package br.edu.fapi.web.sga.disciplina.api.controller;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.web.sga.api.aluno.repository.model.DisciplinaDTO;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaRequest;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaResponse;
import br.edu.fapi.web.sga.disciplina.api.model.DisciplinaRest;
import br.edu.fapi.web.sga.disciplina.api.service.DisciplinaBussinesService;

@RestController

public class DisciplinaController {

	@Autowired
	private DisciplinaBussinesService disciplinaBussinesService;
	
	@PostMapping(value="/sga/disciplinas")
	@ResponseBody
	public ResponseEntity<DisciplinaRest> cadastrarDisciplina(@RequestBody DisciplinaRequest disciplina) {
		DisciplinaResponse disciplinaResponse = disciplinaBussinesService.cadastrarDisciplina(disciplina);
		if(disciplinaResponse != null) {
			return ResponseEntity.ok().body(disciplinaResponse);
		}else {
			
		//DisciplinaError disciplinaError = DisciplinaError.builder().error(
			//	Error.builder()
			//	.codigoErroSga("101001")
			//	.descricaoErroSga("Erro de cadastrado.")
			//	.detalheErroSga("Falha durante cadastro do aluno, favor entrar em contato com a equipe de suporte.").build())
		//.build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	}
	}
	
	@GetMapping(value="/sga/disciplinas")
	@ResponseBody
	public ResponseEntity<List<DisciplinaRest>> listarDisciplinas() {
		List<DisciplinaDTO> disciplinaDTO = disciplinaBussinesService.ListarDisciplina();
		if(disciplinaDTO != null) {
			ResponseEntity.ok().body(disciplinaDTO);
		}else {
		return null;
		}
		return null;
		
	}
	
	@PutMapping(value="/sga/disciplinas")
	@ResponseBody
	public ResponseEntity<DisciplinaRest> atualizarDisciplina(@RequestBody DisciplinaRequest disciplina) {
		return null;
	}
	
	@DeleteMapping(value="/sga/disciplinas/{id-disciplina}")
	@ResponseBody
	public ResponseEntity<DisciplinaRest> excluirDisciplina(@PathParam("id-disciplina") int idDisciplina) {
		DisciplinaResponse disciplinaResponse = disciplinaBussinesService.DeletarDisciplina(idDisciplina);
		if(disciplinaResponse != null) {
			return ResponseEntity.ok().body(disciplinaResponse);
		}else {
		return null;
		}
	}
	
	
}
