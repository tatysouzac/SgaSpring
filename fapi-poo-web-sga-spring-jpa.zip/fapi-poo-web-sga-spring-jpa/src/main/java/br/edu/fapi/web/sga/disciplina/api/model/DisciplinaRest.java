package br.edu.fapi.web.sga.disciplina.api.model;

public class DisciplinaRest {

}
