package br.edu.fapi.web.sga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication(scanBasePackages={"br.edu.fapi.web.sga.disciplina.api.controller.DisciplinaController", "br.edu.fapi.web.sga.disciplina.api.service.DisciplinaBussinesService"})
public class FapiPooWebSgaSpringJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FapiPooWebSgaSpringJpaApplication.class, args);
	}

}
