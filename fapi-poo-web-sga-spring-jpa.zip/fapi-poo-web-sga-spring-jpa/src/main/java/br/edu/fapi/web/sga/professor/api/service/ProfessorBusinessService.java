package br.edu.fapi.web.sga.professor.api.service;

import java.util.List;

import br.edu.fapi.web.sga.api.aluno.repository.model.ProfessorDTO;
import br.edu.fapi.web.sga.professor.api.model.ProfessorRequest;
import br.edu.fapi.web.sga.professor.api.model.ProfessorResponse;

public interface ProfessorBusinessService {

	ProfessorResponse cadastrarProfessor(ProfessorRequest professor);

	public ProfessorResponse Update(ProfessorRequest professor);

	public ProfessorResponse DeletarProfessor(int Id);

	public List<ProfessorDTO> ListarProfessores();
}
