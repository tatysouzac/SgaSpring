package br.edu.fapi.quentefrio.api.model;

public class QuenteFrioRest {

}
