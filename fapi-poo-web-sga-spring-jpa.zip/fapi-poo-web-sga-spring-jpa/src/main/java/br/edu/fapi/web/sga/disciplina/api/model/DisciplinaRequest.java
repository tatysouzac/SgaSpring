package br.edu.fapi.web.sga.disciplina.api.model;

import lombok.Data;


@Data
public class DisciplinaRequest {

	private String cargaHoraria;
	private String nome;
	private String descricao;
	
}
