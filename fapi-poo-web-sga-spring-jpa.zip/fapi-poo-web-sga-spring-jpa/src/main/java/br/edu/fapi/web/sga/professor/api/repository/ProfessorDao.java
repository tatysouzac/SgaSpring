package br.edu.fapi.web.sga.professor.api.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.edu.fapi.web.sga.api.aluno.repository.model.ProfessorDTO;

@Repository
public interface ProfessorDao extends CrudRepository<ProfessorDTO, Integer> {


}
