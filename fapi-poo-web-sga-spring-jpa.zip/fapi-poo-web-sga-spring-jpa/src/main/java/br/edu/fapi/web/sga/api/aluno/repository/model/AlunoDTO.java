package br.edu.fapi.web.sga.api.aluno.repository.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity(name = "aluno")
public class AlunoDTO {

	@Id
	@SequenceGenerator(name = "aluno_matricula_generator", sequenceName = "aluno_matricula_sequence",schema="fapi_sga_jpa", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "aluno_matricula_generator")
	private Integer  matricula;
	
	@Column(name = "nome", length = 128)
	private String nome;
	
	@Column(name = "rg", length = 11)
	private String rg;
	
	@Column(name = "cpf", length = 14)
	private String cpf;
	
	@Column(name = "dtNascimento")
	@Temporal(TemporalType.DATE)
	private Date dtNascimento;
	
	@Column(name = "estadoCivil")
	private String estadoCivil;
	
	@Column(name = "curso")
	private String curso;
	
	@Column(name = "periodo")
	private Integer periodo;
	
	@Column(name = "teste")
	private Integer teste;
	
	@ManyToOne
	private CursoDTO cursoo;
	
}
