package br.edu.fapi.web.sga.turma.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.edu.fapi.web.sga.api.aluno.repository.model.TurmaDTO;
import br.edu.fapi.web.sga.turma.api.model.TurmaRequest;
import br.edu.fapi.web.sga.turma.api.model.TurmaResponse;
import br.edu.fapi.web.sga.turma.api.repository.TurmaDao;

public class TurmaBusinessService implements TurmaBusinessServiceImpl {

	@Autowired
	private TurmaDao turmaDao;
	
	@Override
	public TurmaResponse cadastrarTurma(TurmaRequest turma) {
		TurmaDTO turmaDTO = TurmaDTO.builder()
				.nome(turma.getNome())
				.curso(turma.getCurso())
				.build();
		turmaDao.save(turmaDTO);
		if(turmaDTO.getId() != null) {
			return TurmaResponse.builder().Id(turmaDTO.getId()).build();
		}else {
		return null;
		}
	}

	@Override
	public TurmaResponse Update(TurmaRequest turma) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TurmaResponse DeletarTurma(int Id) {
		turmaDao.deleteById(Id);
		return null;
	}

	@Override
	public List<TurmaDTO> ListarTurmas() {
		return (List<TurmaDTO>) turmaDao.findAll();
	}

}
