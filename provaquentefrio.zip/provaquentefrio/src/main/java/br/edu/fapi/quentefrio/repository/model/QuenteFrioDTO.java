package br.edu.fapi.quentefrio.repository.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity(name = "quentefrio")
public class QuenteFrioDTO {

	@Id
	@SequenceGenerator(name = "codigo_cadastro_generator", sequenceName = "codigo_cadastro_sequence",schema="bd_quentefrio", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "codigo_cadastro_generator")
	private Integer  codigo_cadastro;
	
	@Column(name = "comentario")
	private String comentario;
	
	@Column(name = "temperatura")
	private String temperatura;
	
	@Column(name = "codigo_estado")
	private String codigo_estado;
	
	@Column(name = "data_cadastro")
	@Temporal(TemporalType.DATE)
	private Date data_cadastro;
	
	@Column(name = "codigo_cidade")
	private String codigo_cidade;

	@Column(name = "teste")
	private Integer teste;
	

	
}
