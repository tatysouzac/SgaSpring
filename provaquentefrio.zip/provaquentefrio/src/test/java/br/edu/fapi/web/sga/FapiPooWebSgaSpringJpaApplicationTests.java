package br.edu.fapi.web.sga;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.util.Assert;

import br.edu.fapi.quentefrio.api.repository.QuenteFrioDao;

@SpringBootTest
class FapiPooWebSgaSpringJpaApplicationTests {

	@Autowired
	private QuenteFrioDao quenteFrioDao;
	
	@Test
	@Sql({"/seed_data.sql"})
	public void contextLoads() {
		Assert.isTrue(quenteFrioDao.count() == 2, "O número de alunos deve ser 2.");
	}

}
