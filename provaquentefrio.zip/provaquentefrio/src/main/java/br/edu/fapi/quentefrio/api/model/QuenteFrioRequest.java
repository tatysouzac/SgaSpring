package br.edu.fapi.quentefrio.api.model;

import lombok.Data;

@Data
public class QuenteFrioRequest {

	private Integer codigoCadastro;
	private String codigoEstado;
	private String codigoCidade;
	private String temperatura;
	private String data_cadastro;
	private String comentario;
	
	
}
