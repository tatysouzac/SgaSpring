package br.edu.fapi.web.sga.aluno.api.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.fapi.web.sga.aluno.api.model.AlunoRequest;
import br.edu.fapi.web.sga.aluno.api.model.AlunoResponse;
import br.edu.fapi.web.sga.aluno.api.repository.AlunoDao;
import br.edu.fapi.web.sga.api.aluno.repository.model.AlunoDTO;

@Service
public class AlunoBusinessServiceImpl implements AlunoBusinessService {

	@Autowired
	private AlunoDao alunoDao;

	@Override
	public AlunoResponse cadastrarAluno(AlunoRequest aluno) {
		Date dtNascimento = null;
		try {
			dtNascimento = DateUtils.parseDate(aluno.getDtNascimento(), "dd/MM/yyyy");
		} catch (ParseException e) {
			e.printStackTrace();
		}

		AlunoDTO alunoDTO = AlunoDTO.builder().cpf(aluno.getCpf()).dtNascimento(dtNascimento).curso(aluno.getCurso())
				.estadoCivil(aluno.getEstadoCivil()).nome(aluno.getNome()).periodo(aluno.getPeriodo()).rg(aluno.getRg())
				.build();
		alunoDao.save(alunoDTO);
		if (alunoDTO.getMatricula() != null) {
			return AlunoResponse.builder().matricula(alunoDTO.getMatricula()).build();
		} else {
			return null;
		}
	}

	@Override
	public AlunoResponse Update(AlunoRequest aluno) {
		Optional<AlunoDTO> alunoBase = alunoDao.findById(aluno.getMatricula());
		if (alunoBase.isPresent()) {
			alunoBase.get().setNome(aluno.getNome());
			alunoBase.get().setCurso(aluno.getCurso());
			alunoBase.get().setEstadoCivil(aluno.getEstadoCivil());
			alunoBase.get().setRg(aluno.getRg());
			alunoBase.get().setPeriodo(aluno.getPeriodo());
	
			alunoDao.save(alunoBase.get());
			return AlunoResponse.builder().build();
		}else {
			return null;
		}
		
	}

	@Override
	public AlunoResponse DeletarAluno(int matricula) {
		alunoDao.deleteById(matricula);
		return AlunoResponse.builder().build();
	}

	@Override
	public List<AlunoResponse> ListarAlunos() {

		List<AlunoDTO> alunoListTemp = (List<AlunoDTO>) alunoDao.findAll();
		List<AlunoResponse> alunoResponseList = new ArrayList<AlunoResponse>();
		for (AlunoDTO aluno : alunoListTemp) {
			alunoResponseList.add(AlunoResponse.builder().matricula(aluno.getMatricula()).build());
		}
		return alunoResponseList;
	}

}
