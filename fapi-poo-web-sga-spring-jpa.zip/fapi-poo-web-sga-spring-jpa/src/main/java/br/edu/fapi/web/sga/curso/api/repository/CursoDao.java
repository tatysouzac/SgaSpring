package br.edu.fapi.web.sga.curso.api.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.edu.fapi.web.sga.api.aluno.repository.model.CursoDTO;

@Repository
public interface CursoDao extends CrudRepository<CursoDTO, Integer>{

}
