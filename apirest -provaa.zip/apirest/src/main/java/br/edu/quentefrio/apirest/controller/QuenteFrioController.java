package br.edu.quentefrio.apirest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.quentefrio.apirest.model.QuenteFrio;
import br.edu.quentefrio.apirest.repository.QuenteFrioRepository;

@RestController
@RequestMapping(value = "/api")
public class QuenteFrioController {

	@Autowired
	QuenteFrioRepository quenteFrioRepository;
	
    @PostMapping("/quentefrio")
    public QuenteFrio cadastrar(@RequestBody QuenteFrio quenteFrio) {
    	return quenteFrioRepository.save(quenteFrio);
    }
    
    @PutMapping("/quentefrio")
    public QuenteFrio atualizar(@RequestBody QuenteFrio quentefrio) {
		return quenteFrioRepository.save(quentefrio);
    }
    

	@GetMapping("/quentefrioc/{codCidade}")
	public List<QuenteFrio> listaTempCidade(@PathVariable(value = "codCidade")String codCidade){
		return quenteFrioRepository.findBycodigoCidade(codCidade);
	}
	
	@GetMapping("/quentefrioe/{codEstado}")
	public List<QuenteFrio> listaTempEstado(@PathVariable(value = "codEstado")String codEstado){
		return quenteFrioRepository.findBycodigoEstado(codEstado);
	}
	
	@GetMapping("/quentefriocd/{codCidade}/data/{cadastroData}")
	public QuenteFrio BuscaTempCidDta(@PathVariable("codCidade") String codCidade, @PathVariable("cadastroData") String cadastroData){
		return quenteFrioRepository.findByCodigoCidadeAndCadastroData(codCidade, cadastroData);
	}
	
	@GetMapping("/quentefriod/{cadastroData}")
	public List<QuenteFrio> listaTempData(@PathVariable(value = "cadastroData")String cadastroData){
		return quenteFrioRepository.findByCadastroData(cadastroData);
	}
	

	
	
}
