package br.edu.fapi.web.sga.aluno.api.controller;

import java.util.List;


import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.web.sga.aluno.api.model.AlunoError;
import br.edu.fapi.web.sga.aluno.api.model.AlunoRequest;
import br.edu.fapi.web.sga.aluno.api.model.AlunoResponse;
import br.edu.fapi.web.sga.aluno.api.model.AlunoRest;
import br.edu.fapi.web.sga.aluno.api.model.Error;
import br.edu.fapi.web.sga.aluno.api.service.AlunoBusinessService;

@RestController
public class AlunoController {

	@Autowired
	private AlunoBusinessService alunoBusinessService;

	@PostMapping(value = "/sga/alunos")
	@ResponseBody
	public ResponseEntity<AlunoRest> registrarAluno(@RequestBody AlunoRequest aluno) {
		AlunoResponse alunoResponse = alunoBusinessService.cadastrarAluno(aluno);
		if (alunoResponse != null) {
			return ResponseEntity.ok().body(alunoResponse);
		} else {
			AlunoError alunoError = AlunoError.builder()
					.error(Error.builder().codigoErroSga("101001").descricaoErroSga("Erro de cadastrado.")
							.detalheErroSga(
									"Falha durante cadastro do aluno, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(alunoError);
		}
	}

	@GetMapping(value = "/sga/alunos")
	@ResponseBody
	public ResponseEntity<Object> listarAlunos() {
		List<AlunoResponse> alunoListAll = alunoBusinessService.ListarAlunos();
		if (alunoListAll != null) {
			return ResponseEntity.ok().body(alunoListAll);
		} else {
			AlunoError alunoError = AlunoError.builder()
					.error(Error.builder().codigoErroSga("101004").descricaoErroSga("Erro de Listagem.")
							.detalheErroSga(
									"Falha durante listagem de alunos, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(alunoError);
		}
	}

	@PutMapping(value = "/sga/alunos")
	@ResponseBody
	public ResponseEntity<Object> atualizarAluno(@RequestBody AlunoRequest aluno) {
		AlunoResponse alunoResponse = alunoBusinessService.Update(aluno);
		if(alunoResponse != null) {
			return ResponseEntity.ok().body(alunoResponse);	
		}else {
			
			AlunoError alunoError = AlunoError.builder()
					.error(Error.builder().codigoErroSga("101005").descricaoErroSga("Erro em Atualizar Aluno.")
							.detalheErroSga(
									"Falha durante atualização de aluno, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(alunoError);
		}
	}

	@DeleteMapping(value = "/sga/alunos/{matricula-aluno}")
	@ResponseBody
	public ResponseEntity<Object> excluirAluno(@PathParam("matricula-aluno") int Matricula) {
		AlunoResponse alunoResponse = alunoBusinessService.DeletarAluno(Matricula);
		if (alunoResponse != null) {
			return ResponseEntity.ok().body("Aluno Deletado com Sucesso");
		} else {
			AlunoError alunoError = AlunoError.builder()
					.error(Error.builder().codigoErroSga("101006").descricaoErroSga("Erro em Deletar Aluno.")
							.detalheErroSga(
									"Falha durante a exclusão de aluno, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(alunoError);
		}
	}

}
