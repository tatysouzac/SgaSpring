package br.edu.quentefrio.apirest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.quentefrio.apirest.model.QuenteFrio;
import br.edu.quentefrio.apirest.repository.QuenteFrioRepository;

@RestController
@RequestMapping(value = "/api")
public class QuenteFrioController {

	@Autowired
	QuenteFrioRepository quenteFrioRepository;
	
	@GetMapping("/quentefrio")
	public List<QuenteFrio> listaTemp(){
		return quenteFrioRepository.findAll();
	}

	@GetMapping("/quentefrioc/{codCidade}")
	public List<QuenteFrio> listaTempCidade(@PathVariable(value = "codCidade")String codCidade){
		return quenteFrioRepository.findBycodigoCidade(codCidade);
	}
	
	@GetMapping("/quentefrioe/{codEstado}")
	public List<QuenteFrio> listaTempEstado(@PathVariable(value = "codEstado")String codEstado){
		return quenteFrioRepository.findBycodigoEstado(codEstado);
	}
}
