package br.edu.fapi.web.sga.professor.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.fapi.web.sga.api.aluno.repository.model.ProfessorDTO;
import br.edu.fapi.web.sga.professor.api.model.ProfessorRequest;
import br.edu.fapi.web.sga.professor.api.model.ProfessorResponse;
import br.edu.fapi.web.sga.professor.api.repository.ProfessorDao;

@Service
public class ProfessorBusinessServiceImpl implements ProfessorBusinessService {

	@Autowired
	private ProfessorDao professorDao;

	@Override
	public ProfessorResponse cadastrarProfessor(ProfessorRequest professor) {

		ProfessorDTO professorDTO = ProfessorDTO.builder().nome(professor.getNome())
				.especialidade(professor.getEspecialidade()).build();
		professorDao.save(professorDTO);
		if (professorDTO.getId() != null) {
			return ProfessorResponse.builder().Id(professorDTO.getId()).build();
		} else {
			return null;
		}

	}

	@Override
	public ProfessorResponse Update(ProfessorRequest professor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProfessorResponse DeletarProfessor(int Id) {
		professorDao.deleteById(Id);
		return null;
	}

	@Override
	public List<ProfessorDTO> ListarProfessores() {

		return (List<ProfessorDTO>) professorDao.findAll();
	}

}
