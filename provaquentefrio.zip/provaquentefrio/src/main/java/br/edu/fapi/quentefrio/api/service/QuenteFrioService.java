package br.edu.fapi.quentefrio.api.service;

import java.util.List;

import br.edu.fapi.quentefrio.api.model.QuenteFrioRequest;
import br.edu.fapi.quentefrio.api.model.QuenteFrioResponse;
import br.edu.fapi.quentefrio.api.model.TempCidadeResponse;

public interface QuenteFrioService {
	

	QuenteFrioResponse cadastrarTemperatura(QuenteFrioRequest temp);

	QuenteFrioResponse CorrigirDados(QuenteFrioRequest temp);

	List<TempCidadeResponse> ListarTemperaturas(String codigo_cidade);

	List<TempCidadeResponse> ListarTemperaturasEstado(String codigo_estado);
}
