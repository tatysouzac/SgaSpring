package br.edu.fapi.web.sga.curso.api.controller;

import java.util.List;

import br.edu.fapi.web.sga.comum.Error;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.web.sga.curso.api.model.CursoError;
import br.edu.fapi.web.sga.curso.api.model.CursoRequest;
import br.edu.fapi.web.sga.curso.api.model.CursoResponse;
import br.edu.fapi.web.sga.curso.api.model.CursoRest;
import br.edu.fapi.web.sga.curso.api.service.CursoBusinessService;

@RestController
public class CursoController {

	@Autowired
	private CursoBusinessService cursoBusinessService;

	@PostMapping(value = "/sga/cursos")
	@ResponseBody
	public ResponseEntity<CursoRest> cadastrarCurso(@RequestBody CursoRequest curso) {
		CursoResponse cursoResponse = cursoBusinessService.cadastrarCurso(curso);
		if (cursoResponse != null) {
			return ResponseEntity.ok().body(cursoResponse);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
	
	@PutMapping(value = "/sga/cursos")
	@ResponseBody
	public ResponseEntity<Object> atualizarAluno(@RequestBody CursoRequest curso) {
		CursoResponse cursoResponse = cursoBusinessService.UpdateCurso(curso);
		if(cursoResponse != null) {
			return ResponseEntity.ok().body(cursoResponse);	
		}else {
			
			CursoError cursoError = CursoError.builder()
					.error(Error.builder().codigoErroSga("101005").descricaoErroSga("Erro em Atualizar Curso.")
							.detalheErroSga(
									"Falha durante atualização de curso, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(cursoError);
		}
	}

	@GetMapping(value = "/sga/cursos")
	@ResponseBody
	public ResponseEntity<Object> listarCurso() {
		List<CursoResponse> cursoListAll = cursoBusinessService.ListarCurso();
		if (cursoListAll != null) {
			return ResponseEntity.ok().body(cursoListAll);
		} else {
			CursoError cursoError = CursoError.builder()
					.error(Error.builder().codigoErroSga("1115").descricaoErroSga("Erro de Listagem.").detalheErroSga(
							"Falha durante listagem de cursos, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(cursoError);
		}
	}

	@DeleteMapping(value = "/sga/cursos/{id-curso}")
	@ResponseBody
	public ResponseEntity<Object> excluirCurso(@PathParam("id-curso") int Id) {

		CursoResponse cursoResponse = cursoBusinessService.DeletarCurso(Id);
		if (cursoResponse != null) {
			return ResponseEntity.ok().body("Aluno Deletado com Sucesso");

		} else {
			CursoError cursoError = CursoError.builder()
					.error(Error.builder().codigoErroSga("1116").descricaoErroSga("Erro de Exlusão.").detalheErroSga(
							"Falha durante a exclusao de curso, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(cursoError);
		}
	}

}
