package br.edu.fapi.web.sga.aluno.api.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.edu.fapi.web.sga.api.aluno.repository.model.AlunoDTO;

@Repository
public interface AlunoDao extends CrudRepository<AlunoDTO, Integer> {
	
}
