package br.edu.fapi.web.sga.api.aluno.repository.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity(name = "turma")
public class TurmaDTO {

	@Id
	@SequenceGenerator(name = "turma_id_generator", sequenceName = "turma_id_generator",schema="fapi_sga_jpa", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "turma_id_generator")
	private Integer  Id;
	
	@Column(name = "nome", length = 128)
	private String nome;
	
	@Column(name = "curso", length = 128)
	private String curso;
	
}
