package br.edu.fapi.web.sga.aluno.api.service;

import java.util.List;


import br.edu.fapi.web.sga.aluno.api.model.AlunoRequest;
import br.edu.fapi.web.sga.aluno.api.model.AlunoResponse;

public interface AlunoBusinessService {

	AlunoResponse cadastrarAluno(AlunoRequest aluno);
	
	AlunoResponse Update(AlunoRequest aluno);
	
	AlunoResponse DeletarAluno(int matricula);
	
	public List<AlunoResponse> ListarAlunos();
}
