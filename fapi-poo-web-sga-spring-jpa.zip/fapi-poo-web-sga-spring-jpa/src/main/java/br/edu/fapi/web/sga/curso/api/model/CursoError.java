package br.edu.fapi.web.sga.curso.api.model;

import br.edu.fapi.web.sga.comum.Error;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CursoError extends CursoRest {

	private Error error;
}
