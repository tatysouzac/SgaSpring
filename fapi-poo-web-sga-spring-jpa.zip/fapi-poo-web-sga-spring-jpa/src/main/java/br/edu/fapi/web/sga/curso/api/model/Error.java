package br.edu.fapi.web.sga.curso.api.model;

import br.edu.fapi.web.sga.curso.api.model.Error;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Error {

	private String codigoErroSga;
	private String descricaoErroSga;
	private String detalheErroSga;
	
}
