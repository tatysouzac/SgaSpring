package br.edu.fapi.web.sga.turma.api.model;

import lombok.Data;

@Data
public class TurmaRequest {

	private String nome;
	private String curso;
}
