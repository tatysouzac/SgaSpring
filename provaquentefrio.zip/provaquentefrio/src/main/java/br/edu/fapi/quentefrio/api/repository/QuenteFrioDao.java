package br.edu.fapi.quentefrio.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import br.edu.fapi.quentefrio.repository.model.QuenteFrioDTO;

@Repository
public interface QuenteFrioDao extends CrudRepository<QuenteFrioDTO, Integer> {
	
	@Query("FROM quentefrio WHERE codigo_cidade = ?1")
	List<QuenteFrioDTO> findByCity(String codigo_cidade);
	  
	@Query("FROM quentefrio WHERE codigo_estado = ?1")
	List<QuenteFrioDTO> findByState(String codigo_estado);
	
	
}
