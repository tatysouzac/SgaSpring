package br.edu.fapi.quentefrio.api.service;

import java.text.ParseException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import br.edu.fapi.quentefrio.api.model.QuenteFrioRequest;
import br.edu.fapi.quentefrio.api.model.QuenteFrioResponse;
import br.edu.fapi.quentefrio.api.model.TempCidadeResponse;
import br.edu.fapi.quentefrio.api.repository.QuenteFrioDao;
import br.edu.fapi.quentefrio.repository.model.QuenteFrioDTO;

@Service
public class QuenteFrioServiceImpl implements QuenteFrioService {

	@Autowired
	private QuenteFrioDao quenteFrioDao;

	@Override
	public QuenteFrioResponse cadastrarTemperatura(QuenteFrioRequest temp) {
		Date data_cadastro = null;
		try {
			data_cadastro = DateUtils.parseDate(temp.getData_cadastro(), "dd/MM/yyyy");
		} catch (ParseException e) {
			e.printStackTrace();
		}

		QuenteFrioDTO quenteFrioDTO = QuenteFrioDTO.builder().codigo_cidade(temp.getCodigoCidade())
				.codigo_estado(temp.getCodigoEstado()).comentario(temp.getComentario()).data_cadastro(data_cadastro)
				.temperatura(temp.getTemperatura()).build();

		quenteFrioDao.save(quenteFrioDTO);
		if (quenteFrioDTO.getCodigo_cadastro() != null) {
			return QuenteFrioResponse.builder().codigoCadastro(quenteFrioDTO.getCodigo_cadastro()).build();
		} else {
			return null;
		}
	}

	@Override
	public QuenteFrioResponse CorrigirDados(QuenteFrioRequest temp) {
		Optional<QuenteFrioDTO> tempBase = quenteFrioDao.findById(temp.getCodigoCadastro());
		if (tempBase.isPresent()) {
			tempBase.get().setCodigo_estado(temp.getCodigoEstado());
			tempBase.get().setCodigo_cidade(temp.getCodigoCidade());
			tempBase.get().setComentario(temp.getComentario());
			tempBase.get().setTemperatura(temp.getTemperatura());
			quenteFrioDao.save(tempBase.get());
			return QuenteFrioResponse.builder().build();
		} else {
			return null;
		}

	}

	@Override
	public List<TempCidadeResponse> ListarTemperaturas(String codigo_cidade) {

		List<QuenteFrioDTO> ListTemp = (List<QuenteFrioDTO>) quenteFrioDao.findByCity(codigo_cidade);
		List<TempCidadeResponse> tempResponseList = new ArrayList<TempCidadeResponse>();
		for (QuenteFrioDTO temp : ListTemp) {
			tempResponseList.add(TempCidadeResponse.builder().temperatura(temp.getTemperatura())
					.codigoCidade(temp.getCodigo_cidade()).build());
		}
		return tempResponseList;
	}

	@Override
	public List<TempCidadeResponse> ListarTemperaturasEstado(String codigo_estado) {
		List<QuenteFrioDTO> ListTemp = (List<QuenteFrioDTO>) quenteFrioDao.findByState(codigo_estado);
		List<TempCidadeResponse> tempResponseList = new ArrayList<TempCidadeResponse>();
		for (QuenteFrioDTO temp : ListTemp) {
			tempResponseList.add(TempCidadeResponse.builder().temperatura(temp.getTemperatura())
					.codigoCidade(temp.getCodigo_cidade()).build());
		}
		return tempResponseList;
	}

}
