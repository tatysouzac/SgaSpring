package br.edu.fapi.web.sga.curso.api.service;

import java.util.List;

import br.edu.fapi.web.sga.curso.api.model.CursoRequest;
import br.edu.fapi.web.sga.curso.api.model.CursoResponse;

public interface CursoBusinessService {
	
	CursoResponse cadastrarCurso(CursoRequest cursos);
	
	CursoResponse UpdateCurso(CursoRequest cursos);
	
	CursoResponse DeletarCurso(int Id);
	
	public List<CursoResponse> ListarCurso();
	
}
