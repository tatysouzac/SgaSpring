package br.edu.fapi.web.sga.turma.api.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fapi.web.sga.api.aluno.repository.model.TurmaDTO;
import br.edu.fapi.web.sga.turma.api.model.TurmaRequest;
import br.edu.fapi.web.sga.turma.api.model.TurmaResponse;
import br.edu.fapi.web.sga.turma.api.model.TurmaRest;
import br.edu.fapi.web.sga.turma.api.service.TurmaBusinessService;

@RestController
public class TurmaController {

	@Autowired
	private TurmaBusinessService turmaBusinessService;

	@PostMapping(value = "/sga/turmas")
	@ResponseBody
	public ResponseEntity<TurmaRest> cadastrarTurma(@RequestBody TurmaRequest turma) {
		TurmaResponse turmaResponse = turmaBusinessService.cadastrarTurma(turma);
		if (turmaResponse != null) {
			return ResponseEntity.ok().body(turmaResponse);

		} else {
			return null;
		}
	}

	@GetMapping(value = "sga/turmas")
	@ResponseBody
	public ResponseEntity<List<TurmaDTO>> listarTurmas() {
		List<TurmaDTO> turmaDTO = turmaBusinessService.ListarTurmas();
		if (turmaDTO != null) {
			return ResponseEntity.ok().body(turmaDTO);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	@PutMapping(value = "/sga/turmas")
	@ResponseBody
	public ResponseEntity<TurmaRest> atualizarTurma(@RequestBody TurmaRest turma) {
		return null;
	}

	@DeleteMapping(value = "/sga/turmas/{id-turma}")
	@ResponseBody
	public ResponseEntity<TurmaRest> excluirTurma(@PathParam("id-turma") int IdTurma) {
		TurmaResponse turmaResponse = turmaBusinessService.DeletarTurma(IdTurma);
		if (turmaResponse != null) {
			return ResponseEntity.ok().body(turmaResponse);
		} else {
			return null;
		}
	}

}
