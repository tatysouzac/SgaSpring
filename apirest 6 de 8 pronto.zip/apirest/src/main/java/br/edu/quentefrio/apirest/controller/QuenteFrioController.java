package br.edu.quentefrio.apirest.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import br.edu.quentefrio.apirest.model.QuenteFrio;
import br.edu.quentefrio.apirest.model.QuenteFrioError;
import br.edu.quentefrio.apirest.model.Error;
import br.edu.quentefrio.apirest.repository.QuenteFrioRepository;

@RestController
@RequestMapping(value = "/api")
public class QuenteFrioController {

	@Autowired
	QuenteFrioRepository quenteFrioRepository;
	
    @PostMapping("/quentefrio")
    @ResponseBody
    public ResponseEntity<Object> cadastrar(@RequestBody QuenteFrio quenteFrio) {
    	QuenteFrio quentefrio = quenteFrioRepository.save(quenteFrio);
    	if(quentefrio != null) {
			return ResponseEntity.ok().body(quentefrio);
		}else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("100").descricaoErro("Erro Cadastro Temperatura.").detalheErro(
							"Falha durante o cadastro de temperatura, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
    }
    
    @PutMapping("/quentefrio")
    @ResponseBody
    public ResponseEntity<Object> atualizar(@RequestBody QuenteFrio quentefrio) {
		QuenteFrio quentefrioup = quenteFrioRepository.save(quentefrio);
		if(quentefrioup != null) {
			return ResponseEntity.ok().body(quentefrioup);
		}else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("101").descricaoErro("Erro Atuaizar Temperatura.").detalheErro(
							"Falha durante atualização de temperatura, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
    }
    

	@GetMapping("/quentefrioc/{codCidade}")
	@ResponseBody
	public ResponseEntity<Object> listaTempCidade(@PathVariable(value = "codCidade")String codCidade){
		List<QuenteFrio> quentefrio = quenteFrioRepository.findBycodigoCidade(codCidade);
	if(quentefrio != null) {
		return ResponseEntity.ok().body(quentefrio);
	}else {
		QuenteFrioError quenteFrioError = QuenteFrioError.builder()
				.error(Error.builder().codigoErro("102").descricaoErro("Erro em Listar Temperatura.").detalheErro(
						"Falha durante lisatgem de temperaturas, favor entrar em contato com a equipe de suporte.")
						.build())
				.build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
	}
	}
	
	@GetMapping("/quentefrioe/{codEstado}")
	@ResponseBody
	public ResponseEntity<Object> listaTempEstado(@PathVariable(value = "codEstado")String codEstado){
		List<QuenteFrio> quentefrio = quenteFrioRepository.findBycodigoEstado(codEstado);
		if(quentefrio != null) {
			return ResponseEntity.ok().body(quentefrio);
		}else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("103").descricaoErro("Erro em Listar Temperatura.").detalheErro(
							"Falha durante lisatgem de temperaturas, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}
	
	@GetMapping("/quentefriocd/{codCidade}/data/{cadastroData}")
	@ResponseBody
	public ResponseEntity<Object> BuscaTempCidDta(@PathVariable("codCidade") String codCidade, @PathVariable("cadastroData") String cadastroData){
		QuenteFrio quentefrio = quenteFrioRepository.findByCodigoCidadeAndCadastroData(codCidade, cadastroData);
		if(quentefrio != null) {
			return ResponseEntity.ok().body(quentefrio);
		}else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("104").descricaoErro("Erro em Buscar Temperatura.").detalheErro(
							"Falha durante a busca de temperaturas, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}
	
	@GetMapping("/quentefriod/{cadastroData}")
	@ResponseBody
	public ResponseEntity<Object> listaTempData(@PathVariable(value = "cadastroData")String cadastroData){
		List<QuenteFrio> quentefrio = quenteFrioRepository.findByCadastroData(cadastroData);
		if(quentefrio != null) {
			return ResponseEntity.ok().body(quentefrio);
		}else {
			QuenteFrioError quenteFrioError = QuenteFrioError.builder()
					.error(Error.builder().codigoErro("105").descricaoErro("Erro em Buscar Temperatura.").detalheErro(
							"Falha durante lisatgem de temperaturas, favor entrar em contato com a equipe de suporte.")
							.build())
					.build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(quenteFrioError);
		}
	}
	

	
	
}
