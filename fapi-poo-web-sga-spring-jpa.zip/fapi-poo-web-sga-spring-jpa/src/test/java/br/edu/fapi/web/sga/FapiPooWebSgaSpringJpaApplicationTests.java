package br.edu.fapi.web.sga;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.util.Assert;

import br.edu.fapi.web.sga.aluno.api.repository.AlunoDao;

@SpringBootTest
class FapiPooWebSgaSpringJpaApplicationTests {

	@Autowired
	private AlunoDao alunoDao;
	
	@Test
	@Sql({"/seed_data.sql"})
	public void contextLoads() {
		Assert.isTrue(alunoDao.count() == 2, "O número de alunos deve ser 2.");
	}

}
