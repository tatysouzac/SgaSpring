package br.edu.fapi.web.sga.professor.api.model;

public class ProfessorRest {

}
