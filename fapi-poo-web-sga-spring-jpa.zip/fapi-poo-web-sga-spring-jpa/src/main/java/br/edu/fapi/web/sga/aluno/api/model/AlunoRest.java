package br.edu.fapi.web.sga.aluno.api.model;

public class AlunoRest {

}
