package br.edu.fapi.web.sga.professor.api.model;

import lombok.Data;

@Data
public class ProfessorRequest {

	private String nome;
	private String especialidade;
}
