package br.edu.fapi.web.sga.turma.api.service;

import java.util.List;

import br.edu.fapi.web.sga.api.aluno.repository.model.TurmaDTO;
import br.edu.fapi.web.sga.turma.api.model.TurmaRequest;
import br.edu.fapi.web.sga.turma.api.model.TurmaResponse;

public interface TurmaBusinessServiceImpl {

TurmaResponse cadastrarTurma(TurmaRequest turma);
TurmaResponse Update(TurmaRequest turma);
TurmaResponse DeletarTurma(int Id);
public List<TurmaDTO> ListarTurmas();

}
