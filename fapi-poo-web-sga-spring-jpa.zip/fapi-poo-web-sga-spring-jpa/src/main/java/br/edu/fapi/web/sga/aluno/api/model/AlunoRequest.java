package br.edu.fapi.web.sga.aluno.api.model;

import lombok.Data;

@Data
public class AlunoRequest {

	private Integer matricula;
	private String nome;
	private String rg;
	private String cpf;
	private String dtNascimento;
	private String estadoCivil;
	private String curso;
	private Integer periodo;
		
}
