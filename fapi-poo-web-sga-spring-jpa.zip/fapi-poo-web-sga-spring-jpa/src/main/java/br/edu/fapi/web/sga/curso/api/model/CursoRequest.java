package br.edu.fapi.web.sga.curso.api.model;

import lombok.Data;

@Data
public class CursoRequest {

	private int Id;
	private String nome;
	private int numPeriodos;
}
