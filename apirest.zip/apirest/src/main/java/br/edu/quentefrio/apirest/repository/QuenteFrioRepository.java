package br.edu.quentefrio.apirest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.quentefrio.apirest.model.QuenteFrio;

public interface QuenteFrioRepository extends JpaRepository<QuenteFrio, Long>{

	List<QuenteFrio> findBycodigoCidade(String codCidade);
	
	List<QuenteFrio> findBycodigoEstado(String codEstado);
}
